package com.example.joshitalks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

import static com.example.joshitalks.R.string.km;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttontokm = (Button)findViewById(R.id.buttontokm);
        Button buttontoMiles = (Button)findViewById(R.id.buttontoMiles);

        buttontokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textBoxMiles = findViewById(R.id.editTextMiles);
                EditText textBoxKm = findViewById(R.id.editTextkm);

                double vMillion = Double.valueOf(textBoxMiles.getText().toString());
                double vlakh = vMillion*10;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxKm.setText(formatVal.format(vlakh));

                Toast.makeText(MainActivity.this, getString(R.string.MtoL), Toast.LENGTH_SHORT).show();


            }
        });

        buttontoMiles.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText textBoxMiles = findViewById(R.id.editTextMiles);
                    EditText textBoxKm = findViewById(R.id.editTextkm);

                    double vlakh = Double.valueOf(textBoxKm.getText().toString());
                    double vMillion = vlakh/10;
                    DecimalFormat formatVal  = new DecimalFormat("##.##");
                    textBoxMiles.setText(formatVal.format(vMillion));

                    Toast.makeText(MainActivity.this,getString(R.string.LtoM), Toast.LENGTH_SHORT).show();

                }
        });

    }


}
