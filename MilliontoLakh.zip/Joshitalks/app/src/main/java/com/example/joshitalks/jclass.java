package com.example.joshitalks;

public class jclass{

    public static void main(String args[]){

        System.out.println("helloej");
    }
}